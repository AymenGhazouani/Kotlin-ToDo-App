package com.example.myapplication

class Task(val id:Int,val label:String,val checked:Boolean) {
}
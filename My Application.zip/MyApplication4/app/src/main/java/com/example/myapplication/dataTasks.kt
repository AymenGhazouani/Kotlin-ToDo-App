package com.example.myapplication

val tasks= listOf<Task>(Task(1,"task # 1",false),
    Task(2,"task # 2",true),
    Task(3,"task # 3",false),
    Task(4,"task # 4",true))